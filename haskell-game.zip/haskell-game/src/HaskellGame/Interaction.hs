module HaskellGame.Interaction where

import Prelude (
                Num(..), Eq(..), Show(..),
                Bool(..), Char(), Int(), Maybe(..),
                (||), (.), otherwise, not, fst, snd
               )

import qualified System.Console.ANSI as Console
import qualified Data.List as List
import Data.List ((++), (!!), elem, any, filter, null, (\\))

import HaskellGame.Datatypes
import HaskellGame.Graphics
import HaskellGame.Battle
import HaskellGame.Utils.Dictionary

{-
  Check if the player's new position would collide with something.
  Return (True, Just x) if there would be a collision with object x.
  Return (True, Nothing) if there would be a collision with a tile or a monster
  Return (False, Nothing) if there would be no collision.
-}

detectCollision :: Scene -> Point -> (Bool, Maybe Object)
detectCollision theScene (x, y) =
  let theLevel = currentLevel theScene
      theMap = map theLevel
      tile = ((tiles theMap) !! y) !! x
      nonDroppedItems = filter (not . isDroppedItem) (objects theLevel)
      objectPositions = List.map position nonDroppedItems
      monsterPositions = List.map position (monsters theLevel)
  in
    if any (== (x, y)) objectPositions then
      let theObject = List.head (filter ((== (x, y)) . position) (objects theLevel))
      in (True, Just theObject)
    else if (notWalkable tile) || (any (== (x, y)) monsterPositions) then
      (True, Nothing)
    else
      (False, Nothing)
  where
    notWalkable Grass = False
    notWalkable _     = True

{- Handle a key press from the player -}

handleInput :: Char -> Scene -> Scene
handleInput c theScene
  | c `elem` ['i', 'j', 'k', 'l'] = movePlayer c theScene
  | c == 'a'                      = doAttack theScene
  | c == 'p'                      = pickUpItem theScene
  | c == 'd'                      = dropItem theScene
  | otherwise                     = theScene
  where
    movePlayer :: Char -> Scene -> Scene
    movePlayer keyPressed oldScene =
      let (x, y) = position (player oldScene)
          newPosition = case keyPressed of
                          'i' -> (x, (y-1))
                          'j' -> ((x-1), y)
                          'k' -> (x, (y+1))
                          'l' -> ((x+1), y)
                          _   -> (x, y)
          newPlayer = (player oldScene) { pos = newPosition }
          isCollision = detectCollision oldScene newPosition
      in
        if (fst isCollision) then
          oldScene { collided = snd isCollision }
        else oldScene { player = newPlayer, collided = Nothing }

    doAttack :: Scene -> Scene
    doAttack oldScene =
      let thePlayer = player oldScene
          theMap = currentLevel oldScene
          allMonsters = monsters theMap
          nearbyMonsters = filter ((==1) . (distance thePlayer)) allMonsters
      in if not (null nearbyMonsters) then
           attackMonsters nearbyMonsters oldScene
         else oldScene { messages = (messages oldScene) ++ missedMessage }

    attackMonsters :: [Monster] -> Scene -> Scene
    --do nothing if there are no monsters
    attackMonsters [] x = x
    --if there are monsters, attack the first one
    attackMonsters (firstMonster:rest) battleScene =
      let oldPlayer = player battleScene
          (newPlayer, newMonster) = fight (oldPlayer, firstMonster)
          (damageP, damageM) = ((health oldPlayer - health newPlayer), (health firstMonster - health newMonster))
          battleMessages = hitMessage newMonster damageM newPlayer damageP
          -- now we need to update the scene to reflect what has happened
          oldLevel = currentLevel battleScene
          oldMonsters = monsters oldLevel
          newMonsters = (newMonster:(List.delete firstMonster oldMonsters))
          oldMessages = messages battleScene
          newMessages = oldMessages ++ battleMessages
          newLevel = oldLevel { monsters = newMonsters }
          newScene = battleScene { player = newPlayer, currentLevel = newLevel, messages = newMessages }
      in -- now we need to battle the next monster, and keep going until there are none left
        attackMonsters rest newScene

    missedMessage :: [Message]
    missedMessage = [(Console.Red, "You flail wildly at empty space! Your attack connects with nothing.")]

    hitMessage :: Monster -> Int -> Player -> Int -> [Message]
    hitMessage monster monsterDamage player playerDamage =
      [(Console.Red, [symbol monster] ++ " hits " ++ [symbol player]  ++ " for " ++ show playerDamage  ++ " damage!"),
       (Console.Red, [symbol player]  ++ " hits " ++ [symbol monster] ++ " for " ++ show monsterDamage ++ " damage!")]

    pickUpMessage :: Item -> [Message]
    pickUpMessage thing = [(Console.Yellow, ("You pick up the " ++ (itemName thing) ++ ", " ++ [symbol thing]))]

    nothingToPickUpMessage :: [Message]
    nothingToPickUpMessage = [(Console.Yellow, "Nothing to pick up here!")]

    dropMessage :: Item -> [Message]
    dropMessage thing = [(Console.Yellow, ("You drop the " ++ (itemName thing) ++ ", " ++ [symbol thing]))]

    cannotDropMessage :: Item -> [Message]
    cannotDropMessage thing = [(Console.Yellow, ("No space here to drop the " ++ (itemName thing) ++ ", " ++ [symbol thing]))]

    nothingToDropMessage :: [Message]
    nothingToDropMessage = [(Console.Yellow, "You don't have anything to drop!")]

    pickUpItem :: Scene -> Scene
    pickUpItem (Scene cl ol p m c) = 
      -- we need to access the objects in current level to get the Dropped objects
      let (Level currentMap currentObjects currentMons) = cl
          -- To get the dropped objects we filter the objects in the current level using the isDroppedItem predicate
          droppedItems = filter(\tempOb -> isDroppedItem tempOb == True) currentObjects
          -- Items found to be on of the Dropped type and on the current level are filtered in order
          -- to see if they are on the same point as the player
          availableDroppedItems = filter(\tempOb -> distance p tempOb == 0) droppedItems
          -- if there are no objects available then the the nothing message os added to the scene
          -- and the function ends
          in if (availableDroppedItems == []) then 
            (Scene cl ol p (m ++ nothingToPickUpMessage ) c)
            -- We need to access the components of player to add items to the inventory
            else  let (Player h e st sk pos i sl) = p
                      -- The objects in the scene we can pick up are removed from the scene
                      updatedCurrentObjects = currentObjects \\ availableDroppedItems
                      -- The current level is now updated to reflect is current state
                      updatedCurrentLevel = (Level currentMap updatedCurrentObjects currentMons)
                      -- The items picked up are added to the inventory
                      updatedInventory = addInventoryItems availableDroppedItems i
                      -- the player is updated to reflect the inventory changes
                      updatedPlayer = (Player h e st sk pos updatedInventory sl)
                      -- The messages are updated to state that the item has been picked
                      updatedMessages = addPickUpMessage availableDroppedItems m
                      -- the scene is updated to reflect these changes
                      in  (Scene updatedCurrentLevel ol updatedPlayer updatedMessages c)

    addInventoryItems :: [Object] -> (SimpleDict [Char] Item)-> (SimpleDict [Char] Item)
    addInventoryItems [] sd = sd
    addInventoryItems (x:xs) sd = 
      let (Dropped i p) = x
          (Item n d ic a) = i
        in addInventoryItems xs (insert n i sd)

    addPickUpMessage :: [Object] -> [Message] -> [Message]
    addPickUpMessage [] m = m
    addPickUpMessage (x:xs) m = 
      let (Dropped i p) = x
          in addPickUpMessage xs (m ++ pickUpMessage i)

    dropItem :: Scene -> Scene
    dropItem (Scene cl ol p m c) = 
      let (Player h e st sk pos i sl) = p
          -- If players inventory is empty we show the nothing to drop message
          in if (empty i == True) then
            (Scene cl ol p (m ++ nothingToDropMessage ) c)           
            -- if the player is standing on an item the cannot drop message is displayed
            else let  dictList = toList i
                      dropItem = dictList !! 0
                      (a, b) = dropItem
                      (Level currentMap currentObjects currentMons) = cl
                      droppedItems = filter(\tempOb -> isDroppedItem tempOb == True) currentObjects
                      localDroppedItems = filter(\tempOb -> distance p tempOb == 0) droppedItems
                      in if (localDroppedItems /= []) then
                          (Scene cl ol p (m ++ (cannotDropMessage b)) c)
                        -- The player is able to drop the item
                        else let updatedDict = delete a i
                                 -- a new object is created using the item info as well as the players position
                                 newObject = (Dropped b pos)
                                 -- the players inventory is updated, removing the dropped item
                                 updatedPlayer = (Player h e st sk pos updatedDict sl)
                                 -- the dropped objects is added to the listof objects in the level
                                 updatedObjects = currentObjects ++ [newObject]
                                 -- the level is updated with the updated objects list
                                 updatedCurrentLevel = (Level currentMap updatedObjects currentMons)
                                 -- the messages are updated to show the dropped message
                                 updatedMessages = m ++ (dropMessage b)
                                 -- the scene is now updated with the new data
                                 in (Scene updatedCurrentLevel ol updatedPlayer updatedMessages c)